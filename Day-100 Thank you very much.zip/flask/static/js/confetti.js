const canvas = document.getElementById('confetti-canvas');
const ctx = canvas.getContext('2d');

// For responsive canvas
function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas, false);
resizeCanvas();

// Create confetti particles
const confettiCount = 200;
const confetti = [];

for (let i = 0; i < confettiCount; i++) {
  confetti.push({
    // random starting position
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height - canvas.height,
    // random velocity
    r: Math.random() * 6 + 4, // radius
    dx: (Math.random() - 0.5) * 2,
    dy: Math.random() * 2 + 2,
    // random color
    color: `hsl(${Math.floor(Math.random() * 360)}, 100%, 50%)`,
  });
}

function drawConfetti() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  confetti.forEach((particle) => {
    ctx.beginPath();
    ctx.arc(particle.x, particle.y, particle.r, 0, 2 * Math.PI, false);
    ctx.fillStyle = particle.color;
    ctx.fill();

    // Move confetti
    particle.x += particle.dx;
    particle.y += particle.dy;

    // Respawn at the top if it goes off screen
    if (particle.y > canvas.height) {
      particle.x = Math.random() * canvas.width;
      particle.y = -10;
    }
  });
  requestAnimationFrame(drawConfetti);
}

// Start the confetti animation
drawConfetti();
