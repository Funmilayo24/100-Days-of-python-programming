from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def home():
    name = "Funmi"
    message = "Flask makes web development fun and simple!"   
    return render_template('index.html', name=name, message=message)

if __name__ == '__main__':
    app.run(debug = True)