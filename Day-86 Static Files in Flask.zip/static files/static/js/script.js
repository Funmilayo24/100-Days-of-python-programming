document.addEventListener('DOMContentLoaded', function () {
    alert('Welcome to Flask!');
});
