from flask import Flask, session, redirect, url_for, request, render_template

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/')
def home():
    return render_template('home.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')    
        session['username'] = username  
        return redirect(url_for('dashboard')) 
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    username = session.get('username')  
    if username:
        return render_template('dashboard.html', username=username)
    return redirect(url_for('login'))  


@app.route('/logout')
def logout():
    session.pop('username', None)  
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)