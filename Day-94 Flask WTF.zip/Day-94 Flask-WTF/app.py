from flask import Flask, render_template, request, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Length

app = Flask(__name__)

# Important: Set a secret key for CSRF protection. 
# For production, use a secure, random key.
app.config['SECRET_KEY'] = 'YOUR_SECRET_KEY'

# Create a RegistrationForm class
class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=20)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    submit = SubmitField('Sign Up')

@app.route('/', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()  # Initialize the form
    
    if form.validate_on_submit():
        # This block runs when a POST request has valid form data
        username = form.username.data
        password = form.password.data
        # Here you could add logic to save the user in a database, etc.
        flash(f"User {username} registered successfully!", "success")
        # flash() is a way to show messages in Flask; "success" is the category
    else:
        # If it's a GET request or the form data is invalid, 
        # you can handle it here or just render the form
        if request.method == 'POST':
            # Form was submitted but not valid
            flash("Error: Please check your form inputs.", "danger")
    return render_template('register.html', form=form)

if __name__ == '__main__':
    app.run(debug=True)
